module.exports = {
  atomicDir: 'AtomicReact',
  bundleDir: 'src/dev/AtomicReactBundle',
  debug: true
}
